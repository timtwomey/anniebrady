WordPress Theme Nameless

Upload the theme folder "nameless" in the folder "theme" and activate the theme.

Please note:

Upload folder "nameless" in the theme folder "/wp-content/themes" and activate the theme.

The size of the image (header.gif) in the header is 850px x 150px and links to the home page of the blog.

Images should not exceed the width of 490 pixels. For smaller pictures in posts insert after the image

the following line: <br class="clear" /> or "<div class="clear"></ div>".

The plugin "gravatar" (included in the zip) must be in the directory "wp-content/plugins" installed and activated when Gravatars should be displayed for the comments.

Replace in file "comments.php" the e-mail address (admin@deineseite.de) by the email address of the admins of the blog. Then the comments of the admin will appear in a different style.

Have fun with the theme