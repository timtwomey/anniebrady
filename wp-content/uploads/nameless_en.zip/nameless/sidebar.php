<div class="sidebar_box">
<h4>Pages</h4>
<ul>
<li class="<?php if ( is_home() or is_archive() or is_single() or is_paged() or is_search() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php echo get_settings('home'); ?>"><?php _e('Home'); ?></a></li>
<?php wp_list_pages('title_li='); ?>
</ul>
</div>

<div class="sidebar_box">
<h4>Categories</h4>
<ul>
<?php wp_list_categories('title_li='); ?>
</ul>
</div>


<div class="sidebar_box">
<h4>Archive</h4>
<ul>
<?php get_archives('monthly', '', 'html', '', '', FALSE); ?>
</ul>
</div>


<div class="sidebar_box">
<h4>Search</h4>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>


<div class="sidebar_box">
<h4>Blogroll</h4>
<ul>
<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
</ul>
</div>


<div class="sidebar_box">
<h4>Meta</h4>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
</div>

<div class="sidebar_box">
<h4>Tipp</h4>
<ul>
<li><a href="http://www.mozilla-europe.org/de/">If it looks weird in your browser, get a better one</a></li>
</ul>
</div>