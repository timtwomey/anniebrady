<div id="footer" class="clearfix">		
		<div class="footer_text">

                <a href="#">Top</a>
                <div>&nbsp;</div>
                <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> is powered by <a href="http://www.wordpress-deutschland.org">WordPress <?php bloginfo('version'); ?></a> and Theme <a href="http://koch-werkstatt.de/2010/03/21/wordpress-theme-nameless/">Nameless</a>.

		</div>
</div>

<?php wp_footer(); ?>
</div> <!--### end header_wrapper ###-->

</body>
</html>